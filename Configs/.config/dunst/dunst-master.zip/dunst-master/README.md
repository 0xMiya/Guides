# Dracula for [Dunst](https://dunst-project.org)

> A dark theme for [Dunst](https://dunst-project.org).

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/dunst](https://draculatheme.com/dunst).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/dunst/graphs/contributors).

[![Tim Clifford](https://github.com/tim-clifford.png?size=100)](https://github.com/tim-clifford) |
--- |
[Tim Clifford](https://github.com/tim-clifford) |

## License

[MIT License](./LICENSE)
